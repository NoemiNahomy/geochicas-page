<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress');

/** MySQL database username */
define('DB_USER', 'wordpressuser');

/** MySQL database password */
define('DB_PASSWORD', 'admin');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
/**define('AUTH_KEY',         'put your unique phrase here');
define('SECURE_AUTH_KEY',  'put your unique phrase here');
define('LOGGED_IN_KEY',    'put your unique phrase here');
define('NONCE_KEY',        'put your unique phrase here');
define('AUTH_SALT',        'put your unique phrase here');
define('SECURE_AUTH_SALT', 'put your unique phrase here');
define('LOGGED_IN_SALT',   'put your unique phrase here');
define('NONCE_SALT',       'put your unique phrase here');
*/
define('AUTH_KEY',         'Y9;RLzfuZq*b95{@%,XM7gQS81*U(>r>8<vMh+t?{1GRo?wqg-O<0tC16cML Q,=');
define('SECURE_AUTH_KEY',  'zS2|3Y|g 3NE:Jau2*%*,dd ea*u$:><(2QWY7RYwO=@KYX5A#^V|]*@=xeD-7e7');
define('LOGGED_IN_KEY',    'yG>yRDHj)A%:h dV7(O$yM2/+!~Lj#h/o7hXk<9WH+L;3xG*=DN<5Mo7$7MB^Y|l');
define('NONCE_KEY',        'W?DV1E*G&DZ+0:q(m(p+Y*51(&Tyk5?AGF$c{#YMtRV|9TGF!E:5^|sT71Dd-/C!');
define('AUTH_SALT',        '{sH`b=Ybdml,})ub&%krdPXJ4Xy1|uX7`|OFL>i^3Mu5w]@6F5R.0hK^&r]fLYqk');
define('SECURE_AUTH_SALT', 'VzA6-3/mmTxOIZWZ1!2z{@7XmhM?MtD>JGHR[jB++=reG2o8PL(o`sFzm/x5<fUy');
define('LOGGED_IN_SALT',   'x4}LX2;%_|wKqy3|c1/{]-&Q^j!7lv$kIIgTql|=_.[hpuNA%-lr#e2TZ#C+QO~+');
define('NONCE_SALT',       'KN#Ai`c/&h8~4m~*);SguJQN:d5uMwg[sbuBS63lf*<*.1YHyZqE+21~~4N8/6f/');





/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
